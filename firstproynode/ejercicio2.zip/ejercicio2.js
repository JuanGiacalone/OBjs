const listaDatos = [
  "jp",
  24,
  true,
  new Date(1997, 8, 12),
  (milibro = {
    titulo: "alguno",
    autor: "yo",
    fecha: new Date(1997, 8, 12),
    url: "url.com",
  }),
];

console.log(listaDatos);
